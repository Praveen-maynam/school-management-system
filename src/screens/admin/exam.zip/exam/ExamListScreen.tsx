
import React, { useState } from 'react';

interface Exam {
	id: number;
	name: string;
	class: string;
	section: string;
	date: string;
	status: 'Scheduled' | 'Completed' | 'Published';
}

const mockExams: Exam[] = [
	{ id: 1, name: 'Midterm Exam', class: '6', section: 'A', date: '2026-02-10', status: 'Scheduled' },
	{ id: 2, name: 'Final Exam', class: '6', section: 'A', date: '2026-04-20', status: 'Completed' },
	{ id: 3, name: 'Quiz 1', class: '7', section: 'B', date: '2026-01-25', status: 'Published' },
];

const classOptions = ['All', '6', '7'];
const sectionOptions = ['All', 'A', 'B'];
const statusOptions = ['All', 'Scheduled', 'Completed', 'Published'];

const ExamListScreen: React.FC = () => {
	const [exams, setExams] = useState<Exam[]>(mockExams);
	const [loading, setLoading] = useState(false);
	const [error, setError] = useState<string | null>(null);
	const [selectedExam, setSelectedExam] = useState<Exam | null>(null);
	const [showAddModal, setShowAddModal] = useState(false);
	const [search, setSearch] = useState('');
	const [classFilter, setClassFilter] = useState('All');
	const [sectionFilter, setSectionFilter] = useState('All');
	const [statusFilter, setStatusFilter] = useState('All');
	const [confirmDelete, setConfirmDelete] = useState<Exam | null>(null);

	const filtered = exams.filter(e =>
		(classFilter === 'All' || e.class === classFilter) &&
		(sectionFilter === 'All' || e.section === sectionFilter) &&
		(statusFilter === 'All' || e.status === statusFilter) &&
		(e.name.toLowerCase().includes(search.toLowerCase()) || e.class.includes(search))
	);

	const handleDelete = (id: number) => {
		setLoading(true);
		setError(null);
		setTimeout(() => {
			setExams((prev) => prev.filter((exam) => exam.id !== id));
			setLoading(false);
			setConfirmDelete(null);
		}, 1000);
	};

	const handleView = (exam: Exam) => {
		setSelectedExam(exam);
	};

	const handleCloseModal = () => {
		setSelectedExam(null);
	};

	const handleExport = () => {
		window.alert('Exported (dummy)');
	};

	const handleAddExam = (e: React.FormEvent) => {
		e.preventDefault();
		setShowAddModal(false);
		// Dummy add
		setExams(prev => [
			...prev,
			{
				id: prev.length + 1,
				name: (e.target as any).name.value,
				class: (e.target as any).class.value,
				section: (e.target as any).section.value,
				date: (e.target as any).date.value,
				status: 'Scheduled',
			},
		]);
	};

	return (
		<div className="max-w-6xl mx-auto p-6 bg-white rounded-lg shadow-md mt-8">
			<div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-4">
				<h2 className="text-2xl font-bold text-gray-800">Exams & Grades</h2>
				<div className="flex gap-2 flex-wrap">
					<button className="btn-primary" onClick={() => setShowAddModal(true)}>+ Add Exam</button>
					<button className="btn-secondary" onClick={handleExport}>Export (Dummy)</button>
				</div>
			</div>
			<div className="flex flex-wrap gap-2 mb-4">
				<input
					className="input w-48"
					placeholder="Search Exam Name or Class"
					value={search}
					onChange={e => setSearch(e.target.value)}
				/>
				<select className="input w-32" value={classFilter} onChange={e => setClassFilter(e.target.value)}>
					{classOptions.map(opt => (
						<option key={opt} value={opt}>{opt === 'All' ? 'All Classes' : `Class ${opt}`}</option>
					))}
				</select>
				<select className="input w-32" value={sectionFilter} onChange={e => setSectionFilter(e.target.value)}>
					{sectionOptions.map(opt => (
						<option key={opt} value={opt}>{opt === 'All' ? 'All Sections' : `Section ${opt}`}</option>
					))}
				</select>
				<select className="input w-40" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
					{statusOptions.map(opt => (
						<option key={opt} value={opt}>{opt === 'All' ? 'All Statuses' : opt}</option>
					))}
				</select>
			</div>
			{loading && <div className="mb-4 text-blue-600">Processing...</div>}
			{error && <div className="mb-4 text-red-600">{error}</div>}
			<div className="overflow-x-auto rounded shadow">
				<table className="min-w-[900px] w-full bg-gray-50 rounded-md overflow-hidden text-sm">
					<thead>
						<tr>
							<th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Name</th>
							<th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Class</th>
							<th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Section</th>
							<th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Date</th>
							<th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Status</th>
							<th className="px-4 py-2 text-left text-xs font-medium text-gray-500">Actions</th>
						</tr>
					</thead>
					<tbody>
						{filtered.length === 0 ? (
							<tr>
								<td colSpan={6} className="px-4 py-2 text-center text-gray-400">No exams found.</td>
							</tr>
						) : (
							filtered.map((exam) => (
								<tr key={exam.id}>
									<td className="px-4 py-2 text-gray-700">{exam.name}</td>
									<td className="px-4 py-2 text-gray-700">{exam.class}</td>
									<td className="px-4 py-2 text-gray-700">{exam.section}</td>
									<td className="px-4 py-2 text-gray-700">{exam.date}</td>
									<td className="px-4 py-2 text-gray-700">{exam.status}</td>
									<td className="px-4 py-2">
										<button
											className="mr-2 px-2 py-1 bg-blue-500 text-white rounded hover:bg-blue-600"
											onClick={() => handleView(exam)}
										>
											View
										</button>
										<button
											className="mr-2 px-2 py-1 bg-green-500 text-white rounded hover:bg-green-600"
											disabled
										>
											Edit
										</button>
										<button
											className="px-2 py-1 bg-red-500 text-white rounded hover:bg-red-600"
											onClick={() => setConfirmDelete(exam)}
											disabled={loading}
										>
											Delete
										</button>
									</td>
								</tr>
							))
						)}
					</tbody>
				</table>
			</div>

			{/* Add Exam Modal */}
			{showAddModal && (
				<div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
					<div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
						<h3 className="text-xl font-bold mb-2">Add Exam</h3>
						<form onSubmit={handleAddExam} className="space-y-3">
							<input className="input w-full" name="name" placeholder="Exam Name" required />
							<select className="input w-full" name="class" required>
								<option value="">Select Class</option>
								<option value="6">6</option>
								<option value="7">7</option>
							</select>
							<select className="input w-full" name="section" required>
								<option value="">Select Section</option>
								<option value="A">A</option>
								<option value="B">B</option>
							</select>
							<input className="input w-full" name="date" type="date" required />
							<div className="flex gap-2 mt-4">
								<button type="submit" className="btn-primary">Add</button>
								<button type="button" className="btn-secondary ml-auto" onClick={() => setShowAddModal(false)}>Cancel</button>
							</div>
						</form>
					</div>
				</div>
			)}

			{/* View Exam Modal */}
			{selectedExam && (
				<div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
					<div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
						<h3 className="text-xl font-bold mb-2">Exam Details</h3>
						<p><span className="font-semibold">Name:</span> {selectedExam.name}</p>
						<p><span className="font-semibold">Class:</span> {selectedExam.class}</p>
						<p><span className="font-semibold">Section:</span> {selectedExam.section}</p>
						<p><span className="font-semibold">Date:</span> {selectedExam.date}</p>
						<p><span className="font-semibold">Status:</span> {selectedExam.status}</p>
						<button
							className="mt-4 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
							onClick={handleCloseModal}
						>
							Close
						</button>
					</div>
				</div>
			)}

			{/* Confirm Delete Modal */}
			{confirmDelete && (
				<div className="fixed inset-0 bg-black bg-opacity-30 flex items-center justify-center z-50">
					<div className="bg-white rounded-lg shadow-lg p-6 w-full max-w-md">
						<h3 className="text-xl font-bold mb-2 text-red-600">Delete Exam?</h3>
						<p>Are you sure you want to delete <span className="font-semibold">{confirmDelete.name}</span>?</p>
						<div className="flex gap-2 mt-4">
							<button className="btn-danger" onClick={() => handleDelete(confirmDelete.id)} disabled={loading}>Delete</button>
							<button className="btn-secondary ml-auto" onClick={() => setConfirmDelete(null)}>Cancel</button>
						</div>
					</div>
				</div>
			)}
		</div>
	);
};

export default ExamListScreen;